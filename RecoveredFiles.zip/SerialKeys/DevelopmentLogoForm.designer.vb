﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DevelopmentLogoForm
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.ApplicationNameLabel = New System.Windows.Forms.Label()
        Me.ShowMainFormInSeconds = New System.Windows.Forms.Timer(Me.components)
        Me.ApplicationImage_48x48 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.ApplicationImage_48x48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ApplicationNameLabel
        '
        Me.ApplicationNameLabel.AutoSize = True
        Me.ApplicationNameLabel.BackColor = System.Drawing.Color.Transparent
        Me.ApplicationNameLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ApplicationNameLabel.Location = New System.Drawing.Point(207, 25)
        Me.ApplicationNameLabel.Name = "ApplicationNameLabel"
        Me.ApplicationNameLabel.Size = New System.Drawing.Size(131, 20)
        Me.ApplicationNameLabel.TabIndex = 2
        Me.ApplicationNameLabel.Text = "Application name"
        Me.ApplicationNameLabel.UseWaitCursor = True
        '
        'ShowMainFormInSeconds
        '
        Me.ShowMainFormInSeconds.Interval = 4000
        '
        'ApplicationImage_48x48
        '
        Me.ApplicationImage_48x48.BackColor = System.Drawing.Color.Transparent
        Me.ApplicationImage_48x48.Location = New System.Drawing.Point(153, 12)
        Me.ApplicationImage_48x48.Name = "ApplicationImage_48x48"
        Me.ApplicationImage_48x48.Size = New System.Drawing.Size(48, 48)
        Me.ApplicationImage_48x48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.ApplicationImage_48x48.TabIndex = 1
        Me.ApplicationImage_48x48.TabStop = False
        Me.ApplicationImage_48x48.UseWaitCursor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(440, 280)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.UseWaitCursor = True
        '
        'DevelopmentLogoForm
        '
        Me.AccessibleDescription = "Peters Software Solutions Splash Screen"
        Me.AccessibleName = "SplashScreen"
        Me.AccessibleRole = System.Windows.Forms.AccessibleRole.Window
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(440, 280)
        Me.ControlBox = False
        Me.Controls.Add(Me.ApplicationNameLabel)
        Me.Controls.Add(Me.ApplicationImage_48x48)
        Me.Controls.Add(Me.PictureBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DevelopmentLogoForm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Peters Software Solutions Application Logo"
        Me.TopMost = True
        Me.UseWaitCursor = True
        CType(Me.ApplicationImage_48x48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents ApplicationImage_48x48 As PictureBox
    Friend WithEvents ApplicationNameLabel As Label
    Friend WithEvents ShowMainFormInSeconds As Timer
End Class
